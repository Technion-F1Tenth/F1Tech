#!/usr/bin/env python

import rospy, time
import numpy as np
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive
import math
MAX_SPEED = 1.5

SLOW_MODE = True

class ReactiveFollowGap():
    def __init__(self):
        # Topics & Subs, Pubs
        lidarscan_topic = '/scan'
        drive_topic = '/vesc/low_level/ackermann_cmd_mux/input/navigation'
        self.bubble_radius = 150
        self.lidar_sub = rospy.Subscriber(lidarscan_topic, LaserScan, self.lidar_callback, queue_size=10)
        self.drive_pub = rospy.Publisher(drive_topic, AckermannDriveStamped, queue_size=10)
        self.current_steeering_angle = 0.0
        self.integral = 0.0
    def safety_callback(self, msg):
        print("REACHED")
        # vel = AckermannDriveStamped()
        # vel.drive.speed = float(0)
        self.drive_pub_.publish(msg)
        rospy.signal_shutdown("Safety Stop")
        

    def preprocess_lidar(self, ranges, lidar_min, lidar_max, angle_increment):
        """ Preprocess the LiDAR scan array. Expert implementation includes:
            1. Setting each value to the mean over some window
            2. Rejecting high values (e.g., > 3m)
        """
        min_angle = -90 * (math.pi / 180)
        max_angle = 90 * (math.pi / 180)
        min_idx = int(math.floor((min_angle - lidar_min) / angle_increment))
        max_idx = int(math.floor((max_angle - lidar_min) / angle_increment))
        threshold = 2.2
        
        proc_ranges = np.array(ranges[min_idx:max_idx])
        proc_ranges[proc_ranges == np.inf] = threshold
        proc_ranges[proc_ranges > threshold] = threshold
        proc_ranges[proc_ranges < threshold] = 0

        return proc_ranges, min_idx, max_idx

    def find_max_gap(self, free_space_ranges):
        """ 
        Return the start index & end index of the max gap in free_space_ranges
        A n-length gap is a n-length series of consecutive non-zero elements in the range
        """
        current_start = None
        current_length = 0
        max_start = None
        max_length = 0
        self.prev_best = 0

        for i, val in enumerate(free_space_ranges):
            if val != 0:
                if current_start is None:  # Starts new gap count
                    current_start = i
                current_length += 1
            else:  # Ends gap
                if current_start is not None and current_length > max_length:  # largest gap until now
                    max_start = current_start
                    max_length = current_length
                current_start = None
                current_length = 0

        if current_start is not None and current_length > max_length:  # At the end if the gap hasn't ended and is largest, end it.
            max_start = current_start
            max_length = current_length

        if max_start is None:
            return None, None  # VERY BAD BUT JUST IN CASE. SHOULD THROW AN ERROR
        else:
            return max_start, max_start + max_length - 1

    def find_best_point(self, start_i, end_i, ranges):
        """Start_i & end_i are start and end indices of max-gap range, respectively
        Return index of best point in ranges
        Naive: Choose the furthest point within ranges and go there
        """
        rg = ranges[start_i:end_i]
        mid = int(math.floor(len(rg)/2))
        return int((start_i+end_i)/2)  # np.argmax()[0] -> No direct equivalent in ROS 1

    def get_velocity(self, steering_angle, adaptive=True):
        if SLOW_MODE:
            return 0.8
        if adaptive:
            velocity = max(MAX_SPEED - abs(np.rad2deg(steering_angle))/50, 0.8)  # Velocity varies smoothly with steering angle
            # print('Velocity: ' + str(velocity))
            return velocity
        if abs(steering_angle) < np.deg2rad(5):
            velocity = 2.3
        elif abs(steering_angle) < np.deg2rad(10):
            velocity = 2.2
        elif abs(steering_angle) < np.deg2rad(15):
            velocity = 2.1
        elif abs(steering_angle) < np.deg2rad(20):
            velocity = 2.0
        elif abs(steering_angle) < np.deg2rad(30):
            velocity = 1.8
        elif abs(steering_angle) < np.deg2rad(40):
            velocity = 1.6
        else:
            velocity = 1.4
        return velocity

    def lidar_callback(self, data):
        """ Process each LiDAR scan as per the Follow Gap algorithm & publish an AckermannDriveStamped Message
        """
        ranges = data.ranges
        (proc_ranges, min_idx, max_idx) = self.preprocess_lidar(ranges, data.angle_min, data.angle_max, data.angle_increment)
        #Find closest point to LiDAR
        closest_index = min(range(len(proc_ranges)), key=proc_ranges.__getitem__)
        print("closest idx", closest_index)
        #Eliminate all points inside 'bubble' (set them to zero)
        # start_index_bubble = max(closest_index-self.bubble_radius, 0)
        # end_index_bubble = min(closest_index+self.bubble_radius, len(proc_ranges))
        # print("indexs:", start_index_bubble, end_index_bubble)
        #proc_ranges[start_index_bubble:end_index_bubble] = 0
        #Find max length gap
        (gap_start, gap_end) = self.find_max_gap(proc_ranges)
        #Find the best point in the gap
        print("gap endpoints", gap_start, gap_end)
        if gap_start != gap_end:
            best_point = self.find_best_point(gap_start, gap_end, proc_ranges)
        else:
            best_point = self.prev_best
        self.prev_best = best_point
        true_index = best_point + min_idx
        print("bp", best_point)
        #Publish Drive message
        desired_angle = true_index * data.angle_increment + data.angle_min

        self.current_steeering_angle = desired_angle

        print(self.current_steeering_angle)
        ackermann_message = AckermannDriveStamped()
        ackermann_message.drive.steering_angle = self.current_steeering_angle
        self.current_steeering_angle = self.current_steeering_angle
        ackermann_message.drive.speed = self.get_velocity(self.current_steeering_angle, False)
        print("velocity", ackermann_message.drive.speed)
        self.drive_pub.publish(ackermann_message)


def main():
    rospy.init_node("reactive_node", anonymous=True)
    reactive_node = ReactiveFollowGap()
    rospy.spin()
    print("WallFollow Initialized")

if __name__ == '__main__':
    main()

    
