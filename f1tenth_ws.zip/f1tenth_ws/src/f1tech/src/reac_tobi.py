#!/usr/bin/env python
from __future__ import print_function
import sys
import math
import numpy as np

#ROS Imports
import rospy
from sensor_msgs.msg import Image, LaserScan
from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive

class reactive_follow_gap:
    def __init__(self):
        #Topics & Subscriptions,Publishers
        lidarscan_topic = '/scan'
        drive_topic = '/vesc/ackermann_cmd_mux/input/navigation'

        self.lidar_sub = rospy.Subscriber(lidarscan_topic, LaserScan, self.lidar_callback) # Subscribe to LIDAR
        self.drive_pub = rospy.Publisher(drive_topic, AckermannDriveStamped, queue_size=10)# Publish to drive
    
         # Algorithm parameters
        self.speed = 2.0  # m/s
        self.gap_threshold = 0.5  # radians
        self.bubble_radius = 0.2  # meters
        self.mean_window = 1  # number of samples

    def preprocess_lidar(self, data):
        """ Preprocess the LiDAR scan array. Expert implementation includes:
            1.Setting each value to the mean over some window
            2.Rejecting high values (eg. > 3m)
        """
        proc_ranges = []
        ranges = np.array(data.ranges)
        angles = np.arange(data.angle_min*180/math.pi, (data.angle_max-data.angle_increment)*180/math.pi, data.angle_increment*180/math.pi)
        idx_end = np.argmin(np.abs(angles - 90))
        idx_start = np.argmin(np.abs(angles + 90))
        view_range =np.arange(idx_start,idx_end,1)
        #ranges=ranges[view_range]
        for i in range(len(ranges)):
            # Set each value to the mean over a window
            #start_i = max(0, i - self.mean_window // 2)
            #end_i = min(len(ranges) - 1, i + self.mean_window // 2)
            #proc_ranges.append(np.mean(ranges[start_i:end_i]))

            # Reject high values
            if ranges[i] > 2.0:
                proc_ranges.append(2.0)
            else:
                proc_ranges.append(ranges[i])
        
        return proc_ranges

    def find_max_gap(self, free_space_ranges):
        """ Return the start index & end index of the max gap in free_space_ranges
        """
        max_start = 0
        max_end = 0
        curr_start = None
        curr_len = 0
        for i in range(len(free_space_ranges)):
            if free_space_ranges[i] > self.gap_threshold:
                if curr_start is None:
                    curr_start = i
                    curr_len = 1
                else:
                    curr_len += 1
            else:
                if curr_start is not None and curr_len > (max_end - max_start):
                    max_start = curr_start
                    max_end = i - 1
                curr_start = None
                curr_len = 0
        if curr_start is not None and curr_len > (max_end - max_start):
            max_start = curr_start
            max_end = len(free_space_ranges) - 1

        return max_start, max_end

    def find_best_point(self, start_i, end_i, ranges):
        """Start_i & end_i are start and end indices of max-gap range, respectively
        Return index of best point in ranges
        Naive: Choose the furthest point within ranges and go there
        """
        """best_d = 0
        best_i = None
        for i in range(start_i, end_i + 1):
            if ranges[i] > 0 and ranges[i] > best_d:
                best_d = ranges[i]
                best_i = i
        if best_i is None:
            return (start_i + end_i) // 2
        else:
            return best_i"""
        return (start_i + end_i) // 2

    def lidar_callback(self, data):
        """ Process each LiDAR scan as per the Follow Gap algorithm & publish an AckermannDriveStamped Message
        """
        
        proc_ranges = self.preprocess_lidar(data)

        # Find closest point to LiDAR
        closest_index = np.argmin(proc_ranges)
        #print("prebubble")
        #print(closest_index)
        #print(proc_ranges[closest_index])
        # Eliminate all points inside 'bubble' (set them to zero) 
        bubble_radius = 1  # in meters
        for i, _ in enumerate(proc_ranges):
            if i < closest_index + bubble_radius / data.angle_increment and i > closest_index - bubble_radius / data.angle_increment:
                proc_ranges[i] = 0
        #print("bubble")
        #print(proc_ranges)
        # Find max length gap 
        start_i, end_i = self.find_max_gap(proc_ranges)

        # Find the best point in the gap 
        best_index = self.find_best_point(start_i, end_i, proc_ranges)

        # Publish Drive message
        drive_msg = AckermannDriveStamped()
        drive_msg.header.stamp = rospy.Time.now()
        drive_msg.header.frame_id = "laser"
        drive_msg.drive.speed = 0.8
        drive_msg.drive.steering_angle = ((best_index ) * data.angle_increment +data.angle_min)
        print((best_index ) * data.angle_increment -data.angle_min)
        self.drive_pub.publish(drive_msg)

def main(args):
    rospy.init_node("FollowGap_node", anonymous=True)
    rfgs = reactive_follow_gap()
    rospy.sleep(0.1)
    rospy.spin()

if __name__ == '__main__':
    main(sys.argv)
