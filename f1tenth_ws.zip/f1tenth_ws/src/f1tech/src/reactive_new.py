#!/usr/bin/env python

import rospy, time
import numpy as np
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive
import math
import copy 
import Queue
MAX_SPEED = 15
SLOW_MODE = False
MIN_THRESHOLD_FOR_CORNER = 1.
CAR_WIDTH = 0.4
THRESHOLD = 2
MAX_LIDAR_RANGE = 5
MAX_ANGLE_DIFF = np.deg2rad(5)
DEPTH_CONST = 1./MAX_LIDAR_RANGE

ANGLES_LENGTH = 10
STEERING_CONST = 10


class ReactiveFollowGap():
    def __init__(self):
        # Topics & Subs, Pubs
        lidarscan_topic = '/scan'
        drive_topic = '/vesc/low_level/ackermann_cmd_mux/input/navigation'
        self.lidar_sub = rospy.Subscriber(lidarscan_topic, LaserScan, self.lidar_callback, queue_size=10)
        self.drive_pub = rospy.Publisher(drive_topic, AckermannDriveStamped, queue_size=10)
        self.current_steeering_angle = 0.0
        self.integral = 0.0
        self.current_velocity = 0
        self.previous_velocity = 0
        self.current_steeering_angle = 0
        self.previous_steering_angle = 0
        self.current_average_depth = 0
        self.current_max_depth = 0
        self.last_steering_angles = []
        self.lookahead_depth = 0
    def safety_callback(self, msg):
        print("REACHED")
        # vel = AckermannDriveStamped()
        # vel.drive.speed = float(0)
        self.drive_pub_.publish(msg)
        rospy.signal_shutdown("Safety Stop")
        
    def remove_corners(self, ranges):
        indices_to_be_zeroed = []
        i = 0
        corners_removed = False
        while i < len(ranges) - 2:
            if np.abs(ranges[i] - ranges[i+1]) > MIN_THRESHOLD_FOR_CORNER and ranges[i] < THRESHOLD and ranges[i+1] < THRESHOLD:
                delta_theta = np.abs(np.arctan(CAR_WIDTH / (2 * ranges[i])))
                if ranges[i] > delta_theta:
                    min_idx = np.argmin(np.abs(ranges - (ranges[i] - delta_theta)))
                else:
                    min_idx = 0
                if ranges[i] < ranges[-1] - delta_theta:
                    max_idx =  np.argmin(np.abs(ranges - (ranges[i] + delta_theta)))
                else:
                    max_idx = len(ranges) - 1
                indices_to_be_zeroed.append([min_idx, max_idx])
                i+= max_idx - min_idx
                corners_removed = True
            if corners_removed:
                i += max_idx - min_idx
            else:
                i += 1

        for indices in indices_to_be_zeroed:
            min_idx = indices[0]
            max_idx = indices[1]
            ranges[min_idx : max_idx] = np.zeros(max_idx-min_idx)
        return ranges


    def preprocess_lidar(self, ranges, lidar_min, lidar_max, angle_increment):
        """ Preprocess the LiDAR scan array. Expert implementation includes:
            1. Setting each value to the mean over some window
            2. Rejecting high values (e.g., > 3m)
        """
        min_angle = -90 * (math.pi / 180)
        max_angle = 90 * (math.pi / 180)
        min_idx = int(math.floor((min_angle - lidar_min) / angle_increment))
        max_idx = int(math.floor((max_angle - lidar_min) / angle_increment))
        
        left_lookahead_idx = int(math.floor((np.deg2rad(-15) - lidar_min) / angle_increment))
        right_lookahead_idx = int(math.floor((np.deg2rad(15) - lidar_min) / angle_increment))

        proc_ranges = np.array(ranges[min_idx:max_idx])
        try:
            self.lookahead_depth = np.average(proc_ranges[left_lookahead_idx : right_lookahead_idx])
        except:
            self.lookahead_depth = 100
        try:
            proc_ranges = self.remove_corners(proc_ranges)
        except:
            pass
        # threshold = max(2., self.current_velocity/MAX_SPEED * 3.)
        threshold = THRESHOLD
        proc_ranges[proc_ranges == np.inf] = threshold
        proc_ranges[proc_ranges > MAX_LIDAR_RANGE] = MAX_LIDAR_RANGE
        proc_ranges[proc_ranges < threshold] = 0
        return proc_ranges, min_idx, max_idx

    def find_max_gap(self, free_space_ranges):
        """ 
        Return the start index & end index of the max gap in free_space_ranges
        A n-length gap is a n-length series of consecutive non-zero elements in the range
        """
        current_start = None
        current_length = 0
        max_start = None
        max_length = 0
        self.prev_best = 0

        for i, val in enumerate(free_space_ranges):
            if val != 0:
                if current_start is None:  # Starts new gap count
                    current_start = i
                current_length += 1
            else:  # Ends gap
                if current_start is not None and current_length > max_length:  # largest gap until now
                    max_start = current_start
                    max_length = current_length
                current_start = None
                current_length = 0

        if current_start is not None and current_length > max_length:  # At the end if the gap hasn't ended and is largest, end it.
            max_start = current_start
            max_length = current_length

        if max_start is None:
            return None, None  # VERY BAD BUT JUST IN CASE. SHOULD THROW AN ERROR
        else:
            self.current_average_depth = np.average(free_space_ranges[max_start : max_start + max_length - 1])
            self.current_max_depth = np.max(free_space_ranges[max_start : max_start + max_length - 1])
            return max_start, max_start + max_length - 1

    def find_best_point(self, start_i, end_i, ranges):
        """Start_i & end_i are start and end indices of max-gap range, respectively
        Return index of best point in ranges
        Naive: Choose the furthest point within ranges and go there
        """
        rg = ranges[start_i:end_i]
        mid = int(math.floor(len(rg)/2))
        return int((start_i+end_i)/2)  # np.argmax()[0] -> No direct equivalent in ROS 1

        # print(ranges[start_i : end_i])
        # return np.argmax(ranges[start_i : end_i])

    def get_velocity(self, steering_angle, adaptive=False):
        if SLOW_MODE:
            return 0.8
        #if adaptive:
        #    velocity = max(MAX_SPEED - abs(np.rad2deg(steering_angle))/50, 0.8)  # Velocity varies smoothly with steering angle
            # print('Velocity: ' + str(velocity))
        #    return velocitys
        if abs(steering_angle) < np.deg2rad(5):
            velocity = MAX_SPEED
        # elif abs(steering_angle) < np.deg2rad(7):
        #     velocity = 5.
        elif abs(steering_angle) < np.deg2rad(10):
            velocity = 3.0#2.5#2.5#2.1
        elif abs(steering_angle) < np.deg2rad(15):
            velocity = 2.1#2.1#2.1
        elif abs(steering_angle) < np.deg2rad(20):
            velocity = 2.3#2.0
        elif abs(steering_angle) < np.deg2rad(30):
            velocity = 1.8
        elif abs(steering_angle) < np.deg2rad(40):
            velocity = 1.6
        else:
            velocity = 1.4

        # if velocity >= 2.1:
        #     velocity += 1.
        # elif velocity >= 2.:
        #     velocity += 0.5
        # if velocity < 5.:
        #     velocity = velocity + self.current_average_depth / (self.current_max_depth * DEPTH_CONST)
        # print('Velocity: ' + str(velocity)
        # try:
        #     if np.abs(self.last_steering_angles[1] - self.last_steering_angles[0]) < np.deg2rad(2):
        #         depth_addition =  min(1., self.current_average_depth*DEPTH_CONST)
        #         velocity = min(MAX_SPEED, velocity+depth_addition)
        # except:
        #     pass
        return velocity


    def lidar_callback(self, data):
        """ Process each LiDAR scan as per the Follow Gap algorithm & publish an AckermannDriveStamped Message
        """
        ranges = data.ranges
        (proc_ranges, min_idx, max_idx) = self.preprocess_lidar(ranges, data.angle_min, data.angle_max, data.angle_increment)
        #Find closest point to LiDAR
        closest_index = min(range(len(proc_ranges)), key=proc_ranges.__getitem__)
        #print("closest idx", closest_index)
        #Eliminate all points inside 'bubble' (set them to zero)
        # start_index_bubble = max(closest_index-self.bubble_radius, 0)
        # end_index_bubble = min(closest_index+self.bubble_radius, len(proc_ranges))
        (gap_start, gap_end) = self.find_max_gap(proc_ranges)
        #Find the best point in the gap
        #print("gap endpoints", gap_start, gap_end)
        if gap_start != gap_end:
            best_point = self.find_best_point(gap_start, gap_end, proc_ranges)
        else:
            best_point = self.prev_best
        self.prev_best = best_point
        true_index = best_point + min_idx
        #print("bp", best_point)
        #Publish Drive message
        desired_angle = true_index * data.angle_increment + data.angle_min

        self.previous_steeering_angle = copy.deepcopy(self.current_steeering_angle)
        self.current_steeering_angle = desired_angle

        #print(self.current_steeering_angle)
        ackermann_message = AckermannDriveStamped()
        ackermann_message.drive.steering_angle = self.current_steeering_angle
        self.current_steeering_angle = self.current_steeering_angle
        velocity  = self.get_velocity(self.current_steeering_angle, False)
        ackermann_message.drive.speed = velocity
        self.previous_velocity = copy.deepcopy(self.current_velocity)
        self.current_velocity = velocity
        if len(self.last_steering_angles) == ANGLES_LENGTH:
            self.last_steering_angles.pop(0)
        self.last_steering_angles.append(self.current_steeering_angle)
        #print("velocity", ackermann_message.drive.speed)
        self.drive_pub.publish(ackermann_message)
        print("steering ange =", np.rad2deg(self.current_steeering_angle))


def main():
    rospy.init_node("reactive_node", anonymous=True)
    reactive_node = ReactiveFollowGap()
    rospy.spin()
    print("WallFollow Initialized")

if __name__ == '__main__':
    main()

    
